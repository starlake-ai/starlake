--SQL
SELECT  bruce.order.customer_id
        , bruce.order.order_id
        , bruce.order.status
        , bruce.order.timestamp
FROM bruce.order
