--SQL
WITH customer_orders AS (
        SELECT  o.customer_id
                , Count( DISTINCT o.order_id ) AS total_orders
                , Sum( o.quantity * p.price ) AS total_spent
                , Min( o.order_date ) AS first_order_date
                , Max( o.order_date ) AS last_order_date
                , List( DISTINCT p.category ) AS purchased_categories
        FROM starbake.orders o
            JOIN starbake.products p
                ON o.product_id = p.product_id
        GROUP BY o.customer_id )
SELECT  co.customer_id
        , Concat( c.first_name, ' ', c.last_name ) AS customer_name
        , c.email
        , co.total_orders
        , co.total_spent
        , co.first_order_date
        , co.last_order_date
        , co.purchased_categories
        , Datediff( 'day', co.first_order_date, co.last_order_date ) AS days_since_first_order
FROM starbake.customers c
    LEFT JOIN customer_orders co
        ON c.id = co.customer_id
ORDER BY co.total_spent DESC NULLS LAST
