#
# Copyright © 2025 Starlake AI (https://starlake.ai)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import os

from typing import List, Optional, Union

from ai.starlake.dataset import StarlakeDataset

from ai.starlake.dagster import StarlakeDagsterJob, StarlakeDagsterUtils, DagsterLogicalDatetimeConfig

from ai.starlake.job import StarlakePreLoadStrategy, StarlakeSparkConfig, StarlakeExecutionEnvironment, TaskType

from dagster import Failure, Output, AssetMaterialization, AssetKey, Out, op, RetryPolicy, OpExecutionContext

from dagster._core.definitions import NodeDefinition

from dagster_shell import execute_shell_command

class StarlakeDagsterCloudRunJob(StarlakeDagsterJob):
    """A StarlakeDagsterJob that runs a starlake command on Google Cloud Run."""

    def __init__(
            self, 
            filename: str=None, 
            module_name: str=None,
            pre_load_strategy: Union[StarlakePreLoadStrategy, str, None]=None, 
            project_id: str=None,
            cloud_run_job_name: str=None,
            cloud_run_job_region: str=None,
            cloud_run_service_account: str = None,
            options: dict=None,
            separator:str = ' ',
            **kwargs) -> None:
        super().__init__(filename=filename, module_name=module_name, pre_load_strategy=pre_load_strategy, options=options, **kwargs)
        self.project_id = __class__.get_context_var(var_name='cloud_run_project_id', default_value=os.getenv("GCP_PROJECT"), options=self.options) if not project_id else project_id
        self.cloud_run_job_name = __class__.get_context_var(var_name='cloud_run_job_name', options=self.options) if not cloud_run_job_name else cloud_run_job_name
        self.cloud_run_job_region = __class__.get_context_var('cloud_run_job_region', default_value=os.getenv("GCP_REGION"), options=self.options) if not cloud_run_job_region else cloud_run_job_region
        self.cloud_run_service_account = __class__.get_context_var(var_name='cloud_run_service_account', default_value="", options=self.options) if not cloud_run_service_account else cloud_run_service_account
        if self.cloud_run_service_account:
            self.impersonate_service_account = f"--impersonate-service-account {self.cloud_run_service_account}"
        else:
            self.impersonate_service_account = ""
        self.separator = separator if separator != ',' else ' '
        if self.sl_env_vars:
            self.update_env_vars = self.separator.join([(f"--update-env-vars \"^{self.separator}^" if i == 0 else "") + f"{key}={value}" for i, (key, value) in enumerate(self.sl_env_vars.items())]) + "\""
        else:
            self.update_env_vars = ""

    @classmethod
    def sl_execution_environment(cls) -> Union[StarlakeExecutionEnvironment, str]:
        """Returns the execution environment to use.

        Returns:
            StarlakeExecutionEnvironment: The execution environment to use.
        """
        return StarlakeExecutionEnvironment.CLOUD_RUN

    def sl_job(self, task_id: str, arguments: list, spark_config: StarlakeSparkConfig=None, dataset: Optional[Union[StarlakeDataset, str]]= None, task_type: Optional[TaskType] = None, **kwargs) -> NodeDefinition:
        """Overrides IStarlakeJob.sl_job()
        Generate the Dagster node that will run the starlake command.

        Args:
            task_id (str): The required task id.
            arguments (list): The required arguments of the starlake command to run.
            spark_config (Optional[StarlakeSparkConfig], optional): The optional spark configuration. Defaults to None.
            dataset (Optional[Union[StarlakeDataset, str]], optional): The optional dataset to materialize. Defaults to None.
            task_type (Optional[TaskType], optional): The optional task type. Defaults to None.

        Returns:
            NodeDefinition: The Dagster node.
        """
        env = self.sl_env(args=arguments)

        sl_command = f"{self.__class__.get_context_var('GOOGLE_CLOUD_SDK', '/usr/local/google-cloud-sdk', self.options)}/bin/gcloud beta run jobs execute {self.cloud_run_job_name} "

        separator = self.separator
        update_env_vars = self.update_env_vars
        region = self.cloud_run_job_region
        project = self.project_id
        impersonate_service_account = self.impersonate_service_account

        if not task_type and len(arguments) > 0:
            task_type = TaskType.from_str(arguments[0])
        transform = task_type == TaskType.TRANSFORM
        params = kwargs.get('params', dict())

        assets: List[AssetKey] = kwargs.get("assets", [])

        ins=kwargs.get("ins", {})

        out:str=kwargs.get("out", "result")
        failure:str=kwargs.get("failure", None)
        skip_or_start = bool(kwargs.get("skip_or_start", False))
        outs=kwargs.get("outs", {out: Out(str, is_required=not skip_or_start and failure is None)})
        if failure:
            outs.update({failure: Out(str, is_required=False)})

        max_retries = int(kwargs.get("retries", self.retries))
        if max_retries > 0:
            retry_policy = RetryPolicy(max_retries=max_retries, delay=self.retry_delay)
        else:
            retry_policy = None

        # Captured via closure into the op below. When set (via sl_pre_load when
        # pre_load_not_ready_sentinel_path is configured in DagInfo options),
        # we consult GCS after a successful gcloud exit to distinguish
        # "files not ready, retry" from "ready, proceed".
        sentinel_path: Optional[str] = kwargs.get("sentinel_path")

        @op(
            name=task_id,
            ins=ins,
            out=outs,
            retry_policy=retry_policy,
        )
        def job(context: OpExecutionContext, config: DagsterLogicalDatetimeConfig, **kwargs):
            if dataset:
                assets.append(StarlakeDagsterUtils.get_asset(context, config, dataset))

            # Mirror Airflow's {{ run_id }} substitution so the Scala CLI receives
            # the same concrete sentinel path the sensor below will check. Without
            # this, the CLI would write to a literal "{{ run_id }}" path that we'd
            # never poll for. Scoped to the --notReadySentinel value to avoid
            # accidentally touching other args that legitimately contain braces.
            local_arguments = list(arguments)
            if sentinel_path:
                from ai.starlake.sentinel import substitute_airflow_placeholders
                resolved_path = substitute_airflow_placeholders(sentinel_path, context.run_id)
                for i, a in enumerate(local_arguments):
                    if a == sentinel_path:
                        local_arguments[i] = resolved_path

            tmp_arguments = []
            tmp_arguments.append("--scheduledDate")
            from datetime import datetime
            from ai.starlake.common import sl_timestamp_format
            logical_datetime: datetime = StarlakeDagsterUtils.get_logical_datetime(context, config).strftime(sl_timestamp_format)
            tmp_arguments.append(f"\'{logical_datetime}\'")
            command = local_arguments[0]
            command_with_arguments = [command] + tmp_arguments + local_arguments[1:]

            if transform:
                opts = command_with_arguments[-1].split(",")
                transform_opts = StarlakeDagsterUtils.get_transform_options(context, config, params).split(',')
                env.update({
                    key: value
                    for opt in transform_opts
                    if "=" in opt  # Only process valid key=value pairs
                    for key, value in [opt.split("=")]
                })
                opts.extend(transform_opts)
                command_with_arguments[-1] = ",".join(opts)

            args = f'^{separator}^' + separator.join(command_with_arguments)

            command = (
                f"{sl_command}"
                f"--args \"{args}\" "
                f"{update_env_vars} "
                f"--wait --region {region} --project {project} --format='get(metadata.name)' {impersonate_service_account}" #--task-timeout 300
            )

            if config.dry_run:
                output, return_code = f"Starlake command {command} execution skipped due to dry run mode.", 0
                context.log.info(output)
            else:
                output, return_code = execute_shell_command(
                    shell_command=command,
                    output_logging="STREAM",
                    log=context.log,
    #                cwd=self.sl_root,
                    env=env,
                    log_shell_command=True,
                )

            if return_code:
                value=f"Starlake command {command} execution failed with output: {output}"
                if retry_policy:
                    retry_count = context.retry_number
                    if retry_count < retry_policy.max_retries:
                        raise Failure(description=value)
                if failure:
                    yield Output(value=value, output_name=failure)
                elif skip_or_start:
                    context.log.info(f"Skipping Starlake command {command} execution due to skip_or_start flag.")
                    return
                else:
                    raise Failure(description=value)
            else:
                # gcloud exited 0. If a sentinel was requested (opt-in via
                # pre_load_not_ready_sentinel_path on DagInfo options), check
                # for the sentinel: if present, the Scala pre-load decided
                # files aren't yet ready. Delete the sentinel and raise Failure
                # so Dagster's retry policy re-runs this op.
                if sentinel_path:
                    from ai.starlake.sentinel import consume_sentinel, substitute_airflow_placeholders
                    from google.cloud import storage

                    # Dagster has no Jinja layer, so we explicitly apply the
                    # same {{ run_id }} substitution Airflow does at render time.
                    # Without this, concurrent Dagster runs would collide on a
                    # single sentinel object (literal "{{ run_id }}" in the path).
                    resolved_sentinel_path = substitute_airflow_placeholders(
                        sentinel_path, context.run_id
                    )

                    storage_client = storage.Client()

                    def _exists(bucket: str, obj: str) -> bool:
                        return storage_client.bucket(bucket).blob(obj).exists()

                    def _delete(bucket: str, obj: str) -> None:
                        storage_client.bucket(bucket).blob(obj).delete()

                    if not consume_sentinel(resolved_sentinel_path, _exists, _delete):
                        raise Failure(
                            description=(
                                f"pre-load: files not ready (sentinel consumed at "
                                f"{resolved_sentinel_path}); Dagster will retry this op"
                            )
                        )

                for asset in assets:
                    yield AssetMaterialization(asset_key=asset.path, description=kwargs.get("description", f"Starlake command {command} execution succeeded"))
                if dataset:
                    yield StarlakeDagsterUtils.get_materialization(context, config, dataset, **kwargs)

                yield Output(value=output, output_name=out)

        return job
